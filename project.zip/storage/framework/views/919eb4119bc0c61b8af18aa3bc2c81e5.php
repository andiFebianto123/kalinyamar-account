


<?php /**PATH C:\laragon\www\project_backpack\vendor/backpack/theme-coreuiv4/resources/views/inc/topbar_left_content.blade.php ENDPATH**/ ?>