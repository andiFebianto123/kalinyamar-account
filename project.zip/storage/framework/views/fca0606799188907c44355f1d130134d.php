<?php Basset::basset('https://cdn.jsdelivr.net/npm/@coreui/coreui@4.2/dist/css/coreui.min.css'); ?>
<?php Basset::basset('https://cdn.jsdelivr.net/npm/simplebar@6.2.5/dist/simplebar.min.css'); ?>


<?php Basset::basset(base_path('vendor/backpack/theme-coreuiv4/resources/assets/css/coreui4.css')); ?><?php /**PATH C:\laragon\www\project_backpack\resources/views/vendor/backpack/theme-coreuiv4/inc/theme_styles.blade.php ENDPATH**/ ?>