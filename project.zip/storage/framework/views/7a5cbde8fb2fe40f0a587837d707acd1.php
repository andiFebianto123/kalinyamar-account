<?php
  $error_number = 403;
?>

<?php echo $__env->make(backpack_view('errors.4xx'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\project_backpack\vendor/backpack/crud/src/resources/views/ui/errors/403.blade.php ENDPATH**/ ?>