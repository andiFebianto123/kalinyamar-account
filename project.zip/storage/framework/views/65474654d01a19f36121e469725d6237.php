


<?php /**PATH C:\laragon\www\project_backpack\resources/views/vendor/backpack/theme-coreuiv4/inc/topbar_left_content.blade.php ENDPATH**/ ?>