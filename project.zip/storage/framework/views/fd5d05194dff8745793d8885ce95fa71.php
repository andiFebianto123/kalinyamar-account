<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(backpack_theme_config('html_direction')); ?>">
<head>
    <?php echo $__env->make(backpack_view('inc.head'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="app flex-row align-items-center">

  <?php echo $__env->yieldContent('header'); ?>

  <div class="container">
  <?php echo $__env->yieldContent('content'); ?>
  </div>

  <footer class="app-footer sticky-footer">
    <?php echo $__env->make(backpack_view('inc.footer'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </footer>

  <?php echo $__env->yieldContent('before_scripts'); ?>
  <?php echo $__env->yieldPushContent('before_scripts'); ?>

  <?php echo $__env->make(backpack_view('inc.scripts'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make(backpack_view('inc.theme_scripts'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <?php echo $__env->yieldContent('after_scripts'); ?>
  <?php echo $__env->yieldPushContent('after_scripts'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\project_backpack\resources/views/vendor/backpack/theme-coreuiv4/layouts/plain.blade.php ENDPATH**/ ?>