<?php Basset::basset('https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js'); ?>
<?php Basset::basset('https://cdn.jsdelivr.net/npm/@coreui/coreui@4.2.4/dist/js/coreui.min.js'); ?>
<?php Basset::basset('https://cdn.jsdelivr.net/npm/simplebar@latest/dist/simplebar.min.js'); ?>
<?php /**PATH C:\laragon\www\project_backpack\vendor/backpack/theme-coreuiv4/resources/views/inc/theme_scripts.blade.php ENDPATH**/ ?>